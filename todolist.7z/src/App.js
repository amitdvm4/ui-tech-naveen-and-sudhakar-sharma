import React,{Component} from 'react';
import TodoLists from './components/todolists';


class App extends Component {
constructor(){
  super();
  this.state={
    lists:[
      {
        id:1,
        name:'Abir',
        Job:'Developer',
        Destination:'Banglore',
        Emp:false

      },
      {
        id:2,
        name:'Rajin',
        Job:'Halwai ',
        Destination:'Banglore',
        Emp:true
      },
      {
        id:3,
        name:'Sandeep',
        Job:'Chef',
        Destination:'Banglore',
        Emp:true

      }
    ]
  }
}

markup=(data)=>{
 this.setState({
   todos:this.state.lists.map(todo=>{
     if(todo.id==data){
       todo.Emp=!todo.Emp
     }
     return todo
   })
 })
  
}
  render(){
  return (
  <div>
  
    <TodoLists data={this.state.lists}   markup={(data)=>this.markup(data)}/> 
    </div>
    
  );
}}

export default App;
