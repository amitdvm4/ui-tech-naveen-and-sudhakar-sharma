import React, { Component } from 'react'
class TodoItem extends Component {
constructor(){
    super();

this.state={
    data:''
}
}

componentWillMount(){
    if(this.props.dataList.Emp==true){
this.setState({
    data:'Employed'
})
    }else
    this.setState({
        data:'Unemployed'
    })
}

Mrkup=(data)=>{
    this.props.markup(data)
}

    render() {
        return (
            <div>
                <input type="checkbox" onChange={()=>this.Mrkup(this.props.dataList.id)}/>
 <div className="Box">{this.props.dataList.name}</div>
                <div className="Box">{this.props.dataList.Job}</div>
                <div className="Box">{this.props.dataList.Destination}</div>


                <div className="Box">{this.state.data}</div>

            </div>
        )
    }
}

export default TodoItem;