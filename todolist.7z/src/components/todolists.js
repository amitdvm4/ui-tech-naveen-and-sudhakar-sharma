import React,{Component} from 'react'
import TodoItem from './todoitem'
class  TodoLists extends Component {
    

// markup=(data)=>{
//     console.log(data)
// }

    render() { 


        return (
            this.props.data.map((toda)=>{
                return(<div>
                <TodoItem dataList={toda} markup={(data)=>this.props.markup(data)} />
                </div>
                )
            })
        )
    }
}
 
export default TodoLists ;