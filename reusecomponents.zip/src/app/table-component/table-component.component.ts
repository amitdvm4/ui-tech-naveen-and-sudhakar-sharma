import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-table-component',
  templateUrl: './table-component.component.html',
  styleUrls: ['./table-component.component.css']
})
export class TableComponentComponent implements OnInit {
  @Input() headers;
  @Input() keys;
  @Input() data;

  @Output() fe=new EventEmitter();
  
  constructor() { }

  ngOnInit() {
  }

  fnEdit(rowData){
    debugger;
    this.fe.emit(rowData);
  }

}
