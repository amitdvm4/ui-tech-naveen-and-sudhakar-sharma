import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TableComponentComponent } from './table-component/table-component.component';
import { SelectComponentComponent } from './select-component/select-component.component';
import { ListComponentComponent } from './list-component/list-component.component';
import { DispUsersComponent } from './disp-users/disp-users.component';

@NgModule({
  declarations: [
    AppComponent,
    TableComponentComponent,
    SelectComponentComponent,
    ListComponentComponent,
    DispUsersComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
