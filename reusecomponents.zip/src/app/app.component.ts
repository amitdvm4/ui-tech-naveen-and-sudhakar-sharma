import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  data:any=[
    {
      'name':'sachin',
      'runs':20000
    },{
      'name':'dhoni',
      'runs':15000
    }
  ];
  h:any=['Name','RUNS'];
  k:any=['name','runs'];
  title = 'reuseablecomponent';

 fnEdit(data){
   debugger;
 }

}
